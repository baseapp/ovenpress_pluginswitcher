<?php
/**
 * Silence is golden.
 *
 * @package Redux Framework
 */

defined( 'ABSPATH' ) || exit;

_deprecated_file( 'field_sorter.php', '4.3', 'class-redux-sorter.php', 'This file has been renamed and is no longer used in Redux 4.  Please change any references to it as it will be removed in future versions of Redux.' );
