<?php

if (! defined('ABSPATH')) exit;

/**
 * File to create must-use plugin for Ovenpress_Plugin_Switcher.
 *
 * @link       https://wpoven.com
 * @since      1.0.0
 *
 * @package    Ovenpress_Plugin_Switcher
 * @subpackage Ovenpress_Plugin_Switcher/mu-plugin
 */


if (!defined('OVENPRESS_PLUGIN_SWITCHER_SLUG'))
    define('OVENPRESS_PLUGIN_SWITCHER_SLUG', 'ovenpress-plugin-switcher');
class Ovenpress_Plugin_Switcher_MU_Plugin
{
    public function __construct()
    {
        // Constructor code, if any
    }

    function matchInput($input, $pattern)
    {
        // Check if pattern is a valid regex
        // We assume a valid regex pattern is enclosed with delimiters
        if (@preg_match($pattern, null) !== FALSE) {
            // It's a regex pattern, perform regex match
            return preg_match($pattern, $input) ? true : false;
        } else {
            // It's a string, perform string match
            return strpos($input, $pattern) !== false ? true : false;
        }
    }

    function processPluginList($orignalList, $userList, $activate = false)
    {
        if ($activate) {
            return $userList;
        }
        return array_diff($orignalList, $userList);
    }


    function processRules($plugins)
    {
        $rules = get_option(OVENPRESS_PLUGIN_SWITCHER_SLUG . '-rules');
        $rulePlugins = array();
        $current_page_url = home_url(add_query_arg(NULL, NULL));
        $current_page_url = trim($current_page_url, "/");
        $current_page_slug = basename(wp_parse_url($current_page_url, PHP_URL_PATH));
        $matchFound = false;

        if (is_array($rules)) {
            foreach ($rules as $rule) {
                if (!isset($rule['status'])) {   // if (!$rule['status']) {
                    continue;
                }
                switch ($rule['type']) {
                    case 'page':
                    case 'post':
                        $item = get_page_by_path($current_page_slug, OBJECT, $rule['type']);
                        $key = $rule['type'] . 's';

                        if (isset($item->ID) && isset($rule[$key]) && in_array($item->ID, $rule[$key])) {
                            if (isset($rule['plugins']) && !empty($rule['plugins'])) {
                                $rulePlugins = $this->processPluginList($plugins, $rule['plugins'], $rule['plugin_status']);
                                $matchFound = true;
                            }
                        }
                        break;

                    case 'home_page':
                        if ((home_url() == $current_page_url) && (isset($rule['plugins']) && !empty($rule['plugins']))) {
                            $rulePlugins = $this->processPluginList($plugins, $rule['plugins'], $rule['plugin_status']);
                            $matchFound = true;
                        }
                        break;

                    case 'url':

                        if (isset($rule['url']) && !empty($rule['url'])) {

                            if (strpos($current_page_url, 'plugins.php')) {
                                break;
                            }

                            if (isset($rule['post_match']) && !empty($rule['post_match'])) {
                                parse_str($rule['post_match'], $post_match);

                                if (is_array($post_match) && is_array($_POST)) {
                                    $result = array_intersect_assoc($post_match, $_POST);
                                }

                                if ((isset($result) && !empty($result)) && (isset($rule['plugins']) && !empty($rule['plugins']))) {
                                    $rulePlugins = $this->processPluginList($plugins, $rule['plugins'], $rule['plugin_status']);
                                    $matchFound = true;
                                    break;
                                }

                                // No match found or plugins empty, break out
                                break;
                            }

                            if ($this->matchInput($current_page_url, $rule['url']) && (isset($rule['plugins']) && !empty($rule['plugins']))) {
                                $rulePlugins = $this->processPluginList($plugins, $rule['plugins'], $rule['plugin_status']);
                                $matchFound = true;
                                break;
                            }
                        }
                        break;

                    case 'front_end':

                        if (
                            ! is_admin()
                            && isset($rule['plugins'])
                            && ! empty($rule['plugins'])
                        ) {

                            // Example: skip wp-login, admin, API, ajax
                            if (
                                strpos($current_page_url, 'wp-login.php') === false &&
                                strpos($current_page_url, 'wp-admin') === false &&
                                strpos($current_page_url, 'wp-json') === false &&
                                !(defined('DOING_AJAX') && DOING_AJAX)
                            ) {
                                $rulePlugins = $this->processPluginList($plugins, $rule['plugins'], $rule['plugin_status']);
                                $matchFound  = true;
                            }
                        }
                        break;
                }
            }
        }

        if (!$matchFound) {
            $rulePlugins = $plugins;
        }

        $plugin_file = OVENPRESS_PLUGIN_SWITCHER_SLUG . '/' . OVENPRESS_PLUGIN_SWITCHER_SLUG . '.php';
        $rulePlugins[] = $plugin_file;

        return $rulePlugins;
    }
}

// Instantiate the class
$ovenpress_plugin_switcher = new Ovenpress_Plugin_Switcher_MU_Plugin();

add_filter('option_active_plugins', array($ovenpress_plugin_switcher, 'processRules'));
